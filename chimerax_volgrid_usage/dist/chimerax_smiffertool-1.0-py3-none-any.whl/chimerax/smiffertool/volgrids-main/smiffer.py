if __name__ != "__main__": exit(0)
import volgrids.smiffer as sm
sm.SmifferApp().run()
