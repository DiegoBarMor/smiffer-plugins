These are some example scripts that use VolGrids as a package
